export enum MailType {
    resetPass = "resetPass",
    signUpVerify = "signUpVerify",
    newPassword = "newPassword"
}
